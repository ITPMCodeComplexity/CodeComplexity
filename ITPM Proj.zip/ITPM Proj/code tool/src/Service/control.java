/**
 * 
 */
package Service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class control {

	
	public ArrayList<int[]> getscore(String code) {
		
		ResultSet rs = null;
		try {
			  Connection con = null;  
			  Statement stmt = null;
			  Class.forName("com.mysql.jdbc.Driver");
			  con =DriverManager.getConnection ("jdbc:mysql://127.0.0.1:3306/codetool","root","");
			  stmt = con.createStatement();
			  rs = stmt.executeQuery("SELECT * FROM weights WHERE wtype ='con'");
			  // displaying records
			  rs.next();
		  
			
			
			}catch(Exception e2){
				
				System.out.print("44");
			}
		
		
		
		int wtcs=0  ,nc ,ccspps ,ccs ;
		
		String lines[] =code.split("\n");
		ArrayList<int[]> score= new ArrayList<int[]>();
		
		
		ccspps = 0 ;
		ccs = 0;
		for(int i = 0 ; i < lines.length ; i++)
		{
			nc=0;
			ccspps=wtcs;
			wtcs = 0 ;
			
			System.out.print(i+" ") ;
			System.out.print(lines[i]+" ");
			

			String words[] = lines[i].split("\\s|\\{|\\(|\\[|\\;|\\}|\\)|\\]"); //splitting due to keywords
						
			for(int j = 0 ; j < words.length ; j++)
			{
				
				
				if(words[j].trim().length()==0)
					continue;
				
				try {
				if(words[j].equals("if") || words[j].equals("else")) {
					
						wtcs=rs.getInt(2);
					
					nc=1;
				}else
				if(words[j].equals("while") || words[j].equals("for")) {
					wtcs=rs.getInt(3);
					nc=1;
				}else
				if(words[j].equals("switch")) {
					wtcs=rs.getInt(4);
					nc=1;
				}else
					if(words[j].equals("case")) {
						wtcs=rs.getInt(5);
						nc=1;
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (wtcs==0) ccspps=0;
			
			
			
			ccs = (wtcs * nc )+ ccspps ;

			
			score.add(new int[] {wtcs,nc,ccspps,ccs});


		}	
		return score;
	}

	

}
