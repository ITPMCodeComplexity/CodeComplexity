/**
 * 
 */
package Service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class csize {
	

	
	
	public ArrayList<int[]> getscore(String code) {
		
		ResultSet rs = null;
		try {
			  Connection con = null;  
			  Statement stmt = null;
			  Class.forName("com.mysql.jdbc.Driver");
			  con =DriverManager.getConnection ("jdbc:mysql://127.0.0.1:3306/codetool","root","");
			  stmt = con.createStatement();
			  rs = stmt.executeQuery("SELECT * FROM weights WHERE wtype ='siz'");
			  rs.next();
		  
			
			
			}catch(Exception e2){
				
				System.out.print("44");
			}
		
		
		
		ArrayList<int[]> score= new ArrayList<int[]>();

		int Nkw  ,Nid ,Nop ,Nnv ,Nsl ,Cs ;
	
		String keywords[] = {"class","static","void","abstract","break","byte","case","catch","continue","default","public" };
		
		String operations[] = {"\\+\\+","\\+","/","--","-","\\*","<=","=","\\.","<"};
		String operations1[] = {"++","+","/","--","-","*","<=","=",".","<"};
		
		String numericalVal[] = {"1,2,3,4,5,6,7,8,9,0"};
		
		String Datatypes[]= {"int", "float" , "char" , "String" , "boolean" , "double" , "date" , "long" , "short"};
		String cs[] = {"for" , "while" , "case" , "switch","if" , "else" , "else if" , "foreach" , "do"};

		String statement[] =code.split("\n");

		
		for(int i = 0 ; i < statement.length ; i++)
		{

			Nkw = 0 ; 
			Nid  = 0 ;
			Nop = 0 ;
			Nnv = 0;
			Nsl =0;
			Cs = 0;
			 
			if(statement[i].indexOf("import")>-1) {
				statement[i]="";
				
			}
			
			System.out.print(i+" ") ;
			System.out.print(statement[i]+" ");
			
			statement[i]=statement[i].trim();
			int aa =statement[i].indexOf("//");
			if(aa>-1)
			statement[i]=statement[i].substring(0,aa);
			
			for(int k = 0 ; k < operations.length ; k++ )
			{
				int s=statement[i].indexOf(operations1[k]);
				
				
				 while(s>0){
					System.out.print("o");
					Nop = Nop + 1;
					statement[i]=statement[i].replaceFirst(operations[k]," ");
					s=statement[i].indexOf(operations1[k]);
				}
			}
					
			
			String words[] = statement[i].split("\\s|\\{|\\(|\\[|\\;|\\}|\\)|\\]"); 
						
			int r0=0;
			int r1=0;
			
			for(int j = 0 ; j < words.length ; j++)
			{
				
				if(words[j].trim().length()==0)
					continue;
				
				for(int k = 0 ; k < keywords.length ; k++ )
				{
					if(words[j].equals(keywords[k]))
					{
						System.out.print("K");
						Nkw = Nkw+1;
						words[j]="";
					}
				}
				
				for(int r= 0 ; r < cs.length ; r++ )
					{
						if(cs[r].equals(words[j]))
						{
							System.out.print("C");
							words[j]="";
						}
					}
										
				
				if(words[j].length()>0 &&  words[j].charAt(0)=='\"') {
					System.out.print("S");
					Nsl = Nsl + 1;
					words[j]="";
				}
				
				
				try {
					Integer.parseInt(words[j]);
					System.out.print("I");
					Nnv = Nnv +1;
					
					words[j]="";
				}catch(Exception g) {
					
				}
				
				r1=r0;
				for(int q = 0 ; q < Datatypes.length ; q++ )
				{
					if(Datatypes[q].equals(words[j]))
					{
						System.out.print("T");
						words[j]="";
						r0=1;
						
					}
				}
				
				
				
				if(words[j].trim().length()>0 && r1==0)
				{
					System.out.print("N");
					
					Nid = Nid +1;
				}
				
				
			}
			
			
			
			try {
				Cs =(rs.getInt(2) * Nkw) + (rs.getInt(3) * Nid) + (rs.getInt(4) * Nop) + (rs.getInt(5) * Nnv) + (rs.getInt(6) * Nsl);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			score.add(new int[] {Nkw,Nid,Nop,Nnv,Nsl,Cs});


			
		}	
		
		return score;
	}

	

}
